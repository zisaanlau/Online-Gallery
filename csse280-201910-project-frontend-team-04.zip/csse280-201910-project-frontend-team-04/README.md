# Managing your CSSE 280 repository

This is the repo that you will use to checkout projects and commit your work 
for feedback and source code management.

Follow instructions from 
https://docs.google.com/document/d/1rX9tJY8LXOZryt56wBjertwTANqT0rKXl365e6stAcA/edit?usp=sharing 
to familiarize yourself with using Git for this course.